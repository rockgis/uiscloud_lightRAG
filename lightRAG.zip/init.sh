#!/usr/bin/env bash
# =============================================================================
#  init-vllm.sh  —  LightRAG + vLLM Stack 초기 설정
#  DGX Spark (ARM64 / Blackwell) 전용
# =============================================================================
set -euo pipefail

BLUE='\033[0;34m'; GREEN='\033[0;32m'
YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

info()  { echo -e "${BLUE}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ─────────────────────────────────────────────────────────────────────────────
info "1/5  환경 확인..."
[[ "$(uname -m)" == "aarch64" ]] || warn "ARM64가 아닙니다: $(uname -m)"
command -v docker &>/dev/null        || error "Docker가 설치되지 않았습니다"
command -v nvidia-smi &>/dev/null    || warn  "nvidia-smi 없음 — GPU 없이 진행"
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader 2>/dev/null || true
ok "환경 확인 완료"

# ─────────────────────────────────────────────────────────────────────────────
info "2/5  .env 설정..."
if [[ ! -f .env ]]; then
    cp .env.example .env
    warn ".env 파일을 .env.example 에서 복사했습니다. HF_TOKEN 및 경로를 확인하세요."
fi
source .env

# ─────────────────────────────────────────────────────────────────────────────
info "3/5  데이터 디렉토리 생성..."
for d in \
    "${HF_CACHE_DIR:-/data/hf_cache}" \
    "${LIGHTRAG_DATA_DIR:-/data/lightrag/data}" \
    "${WEBUI_DATA_DIR:-/data/open-webui}" \
    "./input_docs" "./nginx/conf.d" "./nginx/certs"; do
    mkdir -p "$d" && echo "    $d"
done
ok "디렉토리 준비 완료"

# ─────────────────────────────────────────────────────────────────────────────
info "4/5  컨테이너 시작..."
docker compose -f docker-compose.yml up -d --remove-orphans
ok "컨테이너 시작 완료"

# ─────────────────────────────────────────────────────────────────────────────
info "5/5  vLLM 모델 로딩 대기..."
echo "  (대형 모델 다운로드 및 로딩에 수 분이 걸릴 수 있습니다)"

wait_healthy() {
    local name=$1 url=$2 max=${3:-40}
    for i in $(seq 1 $max); do
        if curl -sf "$url" >/dev/null 2>&1; then
            ok "  [$name] 준비됨 (${i}회 시도)"
            return 0
        fi
        echo -n "."
        sleep 5
    done
    warn "  [$name] 타임아웃 — 로그 확인: docker compose logs $name"
}

wait_healthy "vllm-llm"   "http://localhost:8000/health"  40
wait_healthy "vllm-embed" "http://localhost:8001/health"  30
wait_healthy "lightrag"   "http://localhost:9621/health"  20
wait_healthy "open-webui" "http://localhost:3000/health"  20

# ─────────────────────────────────────────────────────────────────────────────
LLM_NAME="${LLM_SERVED_NAME:-qwen2.5-32b}"
EMB_NAME="${EMBEDDING_SERVED_NAME:-bge-m3}"

echo ""
echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  LightRAG + vLLM 스택 준비 완료!${NC}"
echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
echo ""
printf "  %-12s → %s\n" "Open WebUI"  "http://$(hostname -I | awk '{print $1}'):3000"
printf "  %-12s → %s\n" "LightRAG"   "http://$(hostname -I | awk '{print $1}'):9621"
printf "  %-12s → %s\n" "vLLM LLM"   "http://$(hostname -I | awk '{print $1}'):8000"
printf "  %-12s → %s\n" "vLLM Embed" "http://$(hostname -I | awk '{print $1}'):8001"
echo ""
echo -e "  로드된 모델:"
curl -s http://localhost:8000/v1/models | python3 -c \
    "import sys,json; [print('    LLM  :', m['id']) for m in json.load(sys.stdin).get('data',[])]" 2>/dev/null || true
curl -s http://localhost:8001/v1/models | python3 -c \
    "import sys,json; [print('    Embed:', m['id']) for m in json.load(sys.stdin).get('data',[])]" 2>/dev/null || true
echo ""
echo -e "  모델 변경: ${YELLOW}.env${NC} 수정 후 ${YELLOW}docker compose up -d --force-recreate vllm-llm${NC}"
echo -e "  로그 확인: ${YELLOW}docker compose logs -f vllm-llm${NC}"
echo ""
